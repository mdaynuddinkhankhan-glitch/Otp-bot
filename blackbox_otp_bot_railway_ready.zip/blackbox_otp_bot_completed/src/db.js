const mysql = require("mysql2/promise");

class Database {
  constructor(config) {
    this.pool = mysql.createPool({
      ...config,
      waitForConnections: true,
      connectionLimit: 10,
      queueLimit: 0,
      charset: "utf8mb4",
      decimalNumbers: true
    });
  }

  async ping() {
    const c = await this.pool.getConnection();
    try { await c.ping(); } finally { c.release(); }
  }

  async seedSettings(channels, supportUsername) {
    const rows = [
      ["channel_1_id", channels[0].id],
      ["channel_1_url", channels[0].url],
      ["channel_2_id", channels[1].id],
      ["channel_2_url", channels[1].url]
    ];
    if (supportUsername) rows.push(["support_username", supportUsername]);
    for (const [k, v] of rows) {
      await this.pool.query(
        "INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=IF(setting_value='',VALUES(setting_value),setting_value)",
        [k, v]
      );
    }
  }

  async getSettings() {
    const [rows] = await this.pool.query("SELECT setting_key, setting_value FROM settings");
    return Object.fromEntries(rows.map(r => [r.setting_key, r.setting_value]));
  }

  async setSetting(key, value) {
    await this.pool.query(
      "INSERT INTO settings(setting_key,setting_value) VALUES(?,?) ON DUPLICATE KEY UPDATE setting_value=VALUES(setting_value)",
      [key, String(value)]
    );
  }

  async upsertUser(from, referrerTelegramId = null) {
    const conn = await this.pool.getConnection();
    try {
      await conn.beginTransaction();
      const [existing] = await conn.query("SELECT * FROM users WHERE telegram_id=? FOR UPDATE", [from.id]);
      if (existing.length) {
        await conn.query(
          "UPDATE users SET username=?,first_name=? WHERE telegram_id=?",
          [from.username || null, from.first_name || null, from.id]
        );
        await conn.commit();
        return { ...existing[0], created: false, referrerUserId: existing[0].referred_by || null };
      }

      let referrerUserId = null;
      if (referrerTelegramId && String(referrerTelegramId) !== String(from.id)) {
        const [ref] = await conn.query("SELECT id FROM users WHERE telegram_id=?", [referrerTelegramId]);
        if (ref.length) referrerUserId = ref[0].id;
      }

      const [ins] = await conn.query(
        "INSERT INTO users(telegram_id,username,first_name,referred_by) VALUES(?,?,?,?)",
        [from.id, from.username || null, from.first_name || null, referrerUserId]
      );

      if (referrerUserId) {
        await conn.query(
          "INSERT IGNORE INTO referrals(referrer_user_id,referred_user_id,reward_amount,rewarded) VALUES(?,?,0,0)",
          [referrerUserId, ins.insertId]
        );
      }

      await conn.commit();
      return { id: ins.insertId, telegram_id: from.id, balance: 0, created: true, referrerUserId };
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
  }

  async getUserByTelegramId(tgId) {
    const [rows] = await this.pool.query("SELECT * FROM users WHERE telegram_id=?", [tgId]);
    return rows[0] || null;
  }

  async isBanned(tgId) {
    const [rows] = await this.pool.query("SELECT is_banned FROM users WHERE telegram_id=?", [tgId]);
    return Boolean(rows[0]?.is_banned);
  }

  async adjustBalance(userId, amount, type, note, referenceType = null, referenceId = null) {
    const conn = await this.pool.getConnection();
    try {
      await conn.beginTransaction();
      if (referenceType && referenceId) {
        const [dupe] = await conn.query(
          "SELECT id FROM transactions WHERE reference_type=? AND reference_id=? FOR UPDATE",
          [referenceType, referenceId]
        );
        if (dupe.length) {
          await conn.rollback();
          return { duplicate: true };
        }
      }

      const [u] = await conn.query("SELECT balance FROM users WHERE id=? FOR UPDATE", [userId]);
      if (!u.length) throw new Error("User not found");
      const before = Number(u[0].balance);
      const after = before + Number(amount);
      if (after < 0) throw new Error("Insufficient balance");

      await conn.query("UPDATE users SET balance=? WHERE id=?", [after.toFixed(2), userId]);
      await conn.query(
        "INSERT INTO transactions(user_id,type,amount,balance_before,balance_after,reference_type,reference_id,note) VALUES(?,?,?,?,?,?,?,?)",
        [userId,type,Number(amount).toFixed(2),before.toFixed(2),after.toFixed(2),referenceType,referenceId,note || null]
      );
      await conn.commit();
      return { duplicate: false, before, after };
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally {
      conn.release();
    }
  }

  async createPurchase(userId, amount, sessionId, note) {
    return this.adjustBalance(userId, -Math.abs(amount), "purchase", note, "session", String(sessionId));
  }

  async getBalance(tgId) {
    const [rows] = await this.pool.query("SELECT balance FROM users WHERE telegram_id=?", [tgId]);
    return Number(rows[0]?.balance || 0);
  }

  async saveSession(userId, data) {
    const [r] = await this.pool.query(
      `INSERT INTO sessions(user_id,provider_number,range_code,country_name,iso2,operator_name,sender,provider_expires_ms)
       VALUES(?,?,?,?,?,?,?,?)`,
      [userId,data.number,data.range || null,data.country || null,data.iso2 || null,data.operator || null,data.sender || null,data.expires_ms || null]
    );
    return r.insertId;
  }

  async getOpenSessions(userId) {
    const [rows] = await this.pool.query(
      "SELECT * FROM sessions WHERE user_id=? AND status IN ('allocated','received') ORDER BY created_at DESC",
      [userId]
    );
    return rows;
  }

  async getSession(sessionId, userId = null) {
    const [rows] = await this.pool.query(
      userId ? "SELECT * FROM sessions WHERE id=? AND user_id=?" : "SELECT * FROM sessions WHERE id=?",
      userId ? [sessionId,userId] : [sessionId]
    );
    return rows[0] || null;
  }

  async updateSessionStatus(sessionId, status) {
    await this.pool.query("UPDATE sessions SET status=? WHERE id=?", [status, sessionId]);
  }

  async insertOtpEvent(sessionId, event) {
    const [r] = await this.pool.query(
      `INSERT IGNORE INTO otp_events(session_id,provider_number,sender,message,received_at_ms)
       VALUES(?,?,?,?,?)`,
      [sessionId,event.number,event.sender || null,event.message || null,event.at_ms || null]
    );
    if (r.affectedRows) {
      await this.pool.query("UPDATE sessions SET status='received',last_message_at_ms=? WHERE id=?", [event.at_ms || Date.now(),sessionId]);
      return true;
    }
    return false;
  }

  async listRecentUsers(limit=50) {
    const [rows] = await this.pool.query("SELECT id,telegram_id,username,balance,is_banned,created_at FROM users ORDER BY id DESC LIMIT ?", [limit]);
    return rows;
  }

  async setBan(tgId, banned) {
    await this.pool.query("UPDATE users SET is_banned=? WHERE telegram_id=?", [banned ? 1 : 0, tgId]);
  }

  async getReferralStats(userId) {
    const [rows] = await this.pool.query(
      `SELECT COUNT(*) count, COALESCE(SUM(reward_amount),0) earnings,
       COALESCE(SUM(CASE WHEN rewarded=1 THEN 1 ELSE 0 END),0) rewarded_count
       FROM referrals WHERE referrer_user_id=?`,
      [userId]
    );
    return rows[0];
  }

  async createWithdrawal(userId, method, destination, amount) {
    const conn = await this.pool.getConnection();
    try {
      await conn.beginTransaction();
      const [u] = await conn.query("SELECT balance FROM users WHERE id=? FOR UPDATE", [userId]);
      if (!u.length) throw new Error("User not found");
      const balance = Number(u[0].balance);
      amount = Number(amount);
      if (!Number.isFinite(amount) || amount <= 0 || balance < amount) throw new Error("Insufficient balance");

      await conn.query("UPDATE users SET balance=balance-? WHERE id=?", [amount,userId]);
      const [w] = await conn.query(
        "INSERT INTO withdrawals(user_id,method,destination,amount) VALUES(?,?,?,?)",
        [userId,method,destination,amount]
      );
      await conn.query(
        "INSERT INTO transactions(user_id,type,amount,balance_before,balance_after,reference_type,reference_id,note) VALUES(?,?,?,?,?,?,?,?)",
        [userId,"withdrawal",-amount,balance,balance-amount,"withdrawal",String(w.insertId),`Withdrawal ${method}`]
      );
      await conn.commit();
      return w.insertId;
    } catch (e) {
      await conn.rollback();
      throw e;
    } finally { conn.release(); }
  }

  async listWithdrawals(status=null) {
    const sql = status
      ? `SELECT w.*,u.telegram_id,u.username FROM withdrawals w JOIN users u ON u.id=w.user_id WHERE w.status=? ORDER BY w.id DESC LIMIT 100`
      : `SELECT w.*,u.telegram_id,u.username FROM withdrawals w JOIN users u ON u.id=w.user_id ORDER BY w.id DESC LIMIT 100`;
    const [rows] = await this.pool.query(sql, status ? [status] : []);
    return rows;
  }

  async reviewWithdrawal(id, approve, note) {
    const conn = await this.pool.getConnection();
    try {
      await conn.beginTransaction();
      const [w] = await conn.query("SELECT * FROM withdrawals WHERE id=? FOR UPDATE", [id]);
      if (!w.length) throw new Error("Withdrawal not found");
      if (w[0].status !== "pending") throw new Error("Withdrawal already reviewed");
      if (approve) {
        await conn.query("UPDATE withdrawals SET status='approved',admin_note=?,reviewed_at=NOW() WHERE id=?", [note || null,id]);
      } else {
        const [u] = await conn.query("SELECT balance FROM users WHERE id=? FOR UPDATE", [w[0].user_id]);
        const before = Number(u[0].balance), amount = Number(w[0].amount), after = before + amount;
        await conn.query("UPDATE users SET balance=? WHERE id=?", [after,w[0].user_id]);
        await conn.query("UPDATE withdrawals SET status='rejected',admin_note=?,reviewed_at=NOW() WHERE id=?", [note || null,id]);
        await conn.query(
          "INSERT INTO transactions(user_id,type,amount,balance_before,balance_after,reference_type,reference_id,note) VALUES(?,?,?,?,?,?,?,?)",
          [w[0].user_id,"refund",amount,before,after,"withdrawal",String(id),"Rejected withdrawal refund"]
        );
      }
      await conn.commit();
      return w[0];
    } catch(e) { await conn.rollback(); throw e; }
    finally { conn.release(); }
  }

  async stats() {
    const [[users]] = await this.pool.query("SELECT COUNT(*) count FROM users");
    const [[balance]] = await this.pool.query("SELECT COALESCE(SUM(balance),0) total FROM users");
    const [[sessions]] = await this.pool.query("SELECT COUNT(*) count FROM sessions");
    const [[pending]] = await this.pool.query("SELECT COUNT(*) count FROM withdrawals WHERE status='pending'");
    return { users: users.count, balance: balance.total, sessions: sessions.count, pendingWithdrawals: pending.count };
  }

  async allTelegramIds() {
    const [rows] = await this.pool.query("SELECT telegram_id FROM users WHERE is_banned=0");
    return rows.map(r => r.telegram_id);
  }
}

module.exports = Database;
