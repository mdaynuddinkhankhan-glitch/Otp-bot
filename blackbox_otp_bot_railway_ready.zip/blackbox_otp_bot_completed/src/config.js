require("dotenv").config();

function required(name) {
  const value = process.env[name];
  if (!value) throw new Error(`Missing environment variable: ${name}`);
  return value;
}

const databaseUrl = required("DATABASE_URL");
const parsedDb = new URL(databaseUrl);

module.exports = {
  botToken: required("BOT_TOKEN"),
  adminId: process.env.ADMIN_ID || "",
  botUsername: process.env.BOT_USERNAME || "",
  supportUsername: process.env.SUPPORT_USERNAME || "",
  channels: [
    { id: required("REQUIRED_CHANNEL_1"), url: required("CHANNEL_1_URL") },
    { id: required("REQUIRED_CHANNEL_2"), url: required("CHANNEL_2_URL") }
  ],
  provider: {
    baseUrl: required("ZEBRA_BASE_URL"),
    apiKey: required("ZEBRA_API_KEY")
  },
  database: {
    host: parsedDb.hostname,
    port: Number(parsedDb.port || 3306),
    user: decodeURIComponent(parsedDb.username),
    password: decodeURIComponent(parsedDb.password),
    database: parsedDb.pathname.replace(/^\//, ""),
    ssl: process.env.DATABASE_SSL === "true" ? {} : undefined
  }
};
