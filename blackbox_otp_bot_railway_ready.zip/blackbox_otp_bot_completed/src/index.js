const { Telegraf, Markup, session } = require("telegraf");
const config = require("./config");
const Database = require("./db");
const { ZebraProvider, ProviderError } = require("./provider");
const { migrate } = require("./migrate");

const bot = new Telegraf(config.botToken);
const db = new Database(config.database);
const provider = new ZebraProvider(config.provider);

const rate = new Map();
const LIMIT_WINDOW_MS = 10_000;
const LIMIT_MAX = 8;

function limited(id) {
  const now = Date.now();
  const arr = (rate.get(id) || []).filter(t => now - t < LIMIT_WINDOW_MS);
  arr.push(now);
  rate.set(id, arr);
  return arr.length > LIMIT_MAX;
}

function esc(v) {
  return String(v ?? "").replace(/[<>&]/g, c => ({ "<":"&lt;", ">":"&gt;", "&":"&amp;" }[c]));
}

function money(v) {
  return Number(v || 0).toFixed(2);
}

function mainMenu() {
  return Markup.keyboard([
    ["📱 GET NUMBER", "🔎 SEARCH NUMBER"],
    ["👑 TRAFFIC", "🔐 2FA ONLINE"],
    ["🎁 REFER", "💳 WITHDRAWAL"],
    ["👥 SUPPORT"]
  ]).resize();
}

function backKeyboard() {
  return Markup.inlineKeyboard([[Markup.button.callback("⬅️ Back", "MAIN_MENU")]]);
}

function joinKeyboard(channels) {
  return Markup.inlineKeyboard([
    [Markup.button.url("📢 Join Channel 1", channels[0].url)],
    [Markup.button.url("📢 Join Channel 2", channels[1].url)],
    [Markup.button.callback("✅ I Joined — Check Access", "CHECK_ACCESS")]
  ]);
}

async function getChannelConfig() {
  const s = await db.getSettings();
  return [
    { id: s.channel_1_id || config.channels[0].id, url: s.channel_1_url || config.channels[0].url },
    { id: s.channel_2_id || config.channels[1].id, url: s.channel_2_url || config.channels[1].url }
  ];
}

async function isJoined(ctx, channelId) {
  try {
    const m = await ctx.telegram.getChatMember(channelId, ctx.from.id);
    return ["member", "administrator", "creator"].includes(m.status);
  } catch (e) {
    console.error("Membership check failed:", e.message);
    return false;
  }
}

async function checkAccess(ctx) {
  const channels = await getChannelConfig();
  const joined = await Promise.all(channels.map(c => isJoined(ctx, c.id)));
  return { channels, joined, allJoined: joined.every(Boolean) };
}

async function sendGate(ctx, edit = false) {
  const result = await checkAccess(ctx);
  const missing = result.joined.map((ok,i) => ok ? null : `Channel ${i+1}`).filter(Boolean);
  const text = "🔐 <b>Access Required</b>\n\nTo use this bot, you must join both official channels.\n\n" +
    (missing.length ? `Still required: ${missing.join(", ")}\n` : "") +
    "After joining, press <b>I Joined — Check Access</b>.";
  if (edit) {
    try { await ctx.editMessageText(text, { parse_mode:"HTML", ...joinKeyboard(result.channels) }); }
    catch { await ctx.reply(text, { parse_mode:"HTML", ...joinKeyboard(result.channels) }); }
  } else {
    await ctx.reply(text, { parse_mode:"HTML", ...joinKeyboard(result.channels) });
  }
  return result.allJoined;
}

async function ensureUser(ctx, ref = null) {
  const result = await db.upsertUser(ctx.from, ref);
  if (result.created && result.referrerUserId) {
    const settings = await db.getSettings();
    const reward = Number(settings.referral_reward || 0);
    if (reward > 0) {
      try {
        const tx = await db.adjustBalance(
          result.referrerUserId, reward, "referral_earning",
          `Referral reward for user ${ctx.from.id}`, "referral", String(result.id)
        );
        if (!tx.duplicate) {
          await db.pool.query("UPDATE referrals SET reward_amount=?,rewarded=1 WHERE referred_user_id=?", [reward, result.id]);
        }
      } catch (e) { console.error("Referral reward failed:", e.message); }
    }
  }
  return db.getUserByTelegramId(ctx.from.id);
}

async function protectedFeature(ctx, next) {
  if (!ctx.from) return;
  if (limited(ctx.from.id)) {
    return ctx.reply("⏳ Too many requests. Please wait a few seconds.");
  }
  const user = await ensureUser(ctx);
  if (user.is_banned) return ctx.reply("❌ Your account is restricted. Contact support.");
  if (String(config.adminId) !== String(ctx.from.id)) {
    const access = await checkAccess(ctx);
    if (!access.allJoined) return sendGate(ctx);
  }
  return next();
}

function adminOnly(ctx) {
  return String(config.adminId) && String(config.adminId) === String(ctx.from.id);
}

async function providerError(ctx, err) {
  console.error("Provider error:", err.code || "", err.message);
  let msg = "⚠️ Provider service is temporarily unavailable. Please try again.";
  if (err instanceof ProviderError) {
    if (String(err.code) === "-102") msg = "❌ Provider authentication/account is not authorized or active.";
    if (String(err.code) === "-103") msg = "❌ This provider feature is disabled or forbidden.";
    if (String(err.code) === "-101") msg = "❌ Invalid provider request.";
    if (String(err.code) === "-500") msg = "⏳ Provider server error. Please try again later.";
  }
  return ctx.reply(msg);
}

async function refreshProviderData() {
  const data = await provider.getAvailableRanges();
  const rows = data?.data?.rows;
  if (!Array.isArray(rows)) throw new Error("Invalid liveaccess response");
  for (const row of rows) {
    if (!row.sender || !Array.isArray(row.ranges)) continue;
    await db.setSetting(`provider_service_${row.sender}`, JSON.stringify(row.ranges));
    for (const range of row.ranges) {
      await db.pool.query(
        `INSERT INTO countries(range_code,country_name,iso2,enabled)
         VALUES(?,?,?,1) ON DUPLICATE KEY UPDATE range_code=VALUES(range_code)`,
        [range, null, null]
      );
      await db.pool.query(
        `INSERT INTO services(sender,display_name,enabled)
         VALUES(?,?,1) ON DUPLICATE KEY UPDATE display_name=VALUES(display_name)`,
        [row.sender, row.sender]
      );
    }
  }
  return rows;
}

async function showServices(ctx) {
  try {
    const rows = await refreshProviderData();
    const buttons = [];
    for (const row of rows) {
      if (!row.sender || !row.ranges?.length) continue;
      const [serviceRows] = await db.pool.query("SELECT enabled FROM services WHERE sender=?", [row.sender]);
      if (serviceRows[0] && !serviceRows[0].enabled) continue;
      const placeholders = row.ranges.map(() => "?").join(",");
      const [enabledRanges] = await db.pool.query(
        `SELECT range_code FROM countries WHERE enabled=1 AND range_code IN (${placeholders})`,
        row.ranges
      );
      const enabledSet = new Set(enabledRanges.map(x => x.range_code));
      const count = row.ranges.filter(x => enabledSet.has(x)).length;
      if (!count) continue;
      buttons.push([Markup.button.callback(`📨 ${row.sender} (${count} ranges)`, `PROV_SERVICE:${Buffer.from(row.sender).toString("base64url")}`)]);
    }
    if (!buttons.length) return ctx.reply("❌ No delivering provider ranges are currently available.", backKeyboard());
    await ctx.reply("📱 <b>GET NUMBER</b>\n\nSelect a provider sender/service:", { parse_mode:"HTML", ...Markup.inlineKeyboard(buttons.concat([[Markup.button.callback("⬅️ Back","MAIN_MENU")]])) });
  } catch (e) { return providerError(ctx,e); }
}

bot.use(session());

bot.start(async ctx => {
  try {
    const payload = ctx.startPayload;
    let ref = null;
    if (payload && /^REF_(\d+)$/.test(payload)) ref = payload.replace("REF_","");
    await ensureUser(ctx, ref);
    if (await db.isBanned(ctx.from.id)) return ctx.reply("❌ Your account is restricted.");
    if (String(config.adminId) !== String(ctx.from.id)) {
      const result = await checkAccess(ctx);
      if (!result.allJoined) return sendGate(ctx);
    }
    return ctx.reply("✅ <b>Access verified.</b>\n\nWelcome to <b>BlackBox OTP</b>.", { parse_mode:"HTML", ...mainMenu() });
  } catch(e) {
    console.error("Start error:", e);
    return ctx.reply("⚠️ Unable to start right now. Please try again.");
  }
});

bot.action("CHECK_ACCESS", async ctx => {
  try {
    await ctx.answerCbQuery();
    const result = await checkAccess(ctx);
    if (!result.allJoined) return sendGate(ctx, true);
    await ctx.editMessageText("✅ <b>Both channels verified.</b>", { parse_mode:"HTML" });
    await ctx.reply("Choose an option:", mainMenu());
  } catch(e) { console.error(e); }
});

bot.action("MAIN_MENU", async ctx => {
  try { await ctx.answerCbQuery(); } catch {}
  await ctx.reply("🏠 Main menu:", mainMenu());
});

bot.hears("📱 GET NUMBER", protectedFeature, showServices);

bot.action(/^PROV_SERVICE:(.+)$/, protectedFeature, async ctx => {
  try {
    await ctx.answerCbQuery();
    const sender = Buffer.from(ctx.match[1], "base64url").toString();
    const rows = await refreshProviderData();
    const row = rows.find(r => r.sender === sender);
    if (!row) return ctx.reply("❌ Service is no longer available.", backKeyboard());

    const placeholders = row.ranges.map(() => "?").join(",");
    const [enabledRanges] = await db.pool.query(
      `SELECT range_code FROM countries WHERE enabled=1 AND range_code IN (${placeholders})`,
      row.ranges
    );
    const enabledSet = new Set(enabledRanges.map(x => x.range_code));
    const activeRanges = row.ranges.filter(x => enabledSet.has(x)).slice(0, 60);
    const buttons = activeRanges.map(range => [
      Markup.button.callback(`🌍 ${range}`, `PROV_RANGE:${Buffer.from(range).toString("base64url")}`)
    ]);
    if (!buttons.length) return ctx.reply("❌ No enabled ranges are available for this service.", backKeyboard());
    buttons.push([Markup.button.callback("⬅️ Back", "GET_NUMBER_BACK")]);
    await ctx.editMessageText(
      `📨 <b>${esc(sender)}</b>\n\nSelect a delivering range:`,
      { parse_mode:"HTML", ...Markup.inlineKeyboard(buttons) }
    );
  } catch(e) { return providerError(ctx,e); }
});

bot.action("GET_NUMBER_BACK", protectedFeature, async ctx => {
  try { await ctx.answerCbQuery(); } catch {}
  await ctx.deleteMessage().catch(()=>{});
  return showServices(ctx);
});

bot.action(/^PROV_RANGE:(.+)$/, protectedFeature, async ctx => {
  try {
    await ctx.answerCbQuery("Requesting number...");
    const range = Buffer.from(ctx.match[1], "base64url").toString();
    const settings = await db.getSettings();
    const price = Number(settings.number_price || 0);
    const user = await db.getUserByTelegramId(ctx.from.id);
    if (price > 0) {
      const balance = await db.getBalance(ctx.from.id);
      if (balance < price) return ctx.reply(`❌ Insufficient balance. Required: ${money(price)}, available: ${money(balance)}.`);
    }

    const data = await provider.requestNumber(range);
    const row = data?.data?.rows?.[0];
    if (!row?.number) throw new ProviderError("Provider returned no number.");
    const sessionId = await db.saveSession(user.id, row);

    if (price > 0) {
      try {
        await db.createPurchase(user.id, price, sessionId, `Number ${row.number}`);
      } catch (chargeError) {
        await db.updateSessionStatus(sessionId, "cancel_requested");
        console.error("Purchase charge failed after provider allocation:", chargeError.message);
        return ctx.reply("⚠️ The number was allocated but the local balance charge failed. Admin review is required because the supplied provider API has no documented cancellation endpoint.");
      }
    }

    const expires = row.expires_ms ? Math.max(0, Math.floor((row.expires_ms - Date.now())/1000)) : null;
    const text = [
      "📱 <b>Number Allocated</b>",
      "",
      `🌍 Country: <b>${esc(row.country || "Provider data unavailable")}</b>`,
      `📱 Service: <b>${esc(row.operator || "Provider range")}</b>`,
      `☎️ Number: <code>${esc(row.number)}</code>`,
      `⏳ Status: <b>Allocated</b>`,
      `🆔 Session ID: <code>${sessionId}</code>`,
      expires !== null ? `⏱ Expiration: <b>${Math.floor(expires/60)}m ${expires%60}s</b>` : "⏱ Expiration: Provider did not return expiry",
      price > 0 ? `💳 Charged: <b>${money(price)}</b>` : "💳 Charge: <b>0.00</b> (no provider price configured)"
    ].join("\n");

    await ctx.editMessageText(text, { parse_mode:"HTML", ...Markup.inlineKeyboard([
      [Markup.button.callback("📋 Copy Number", `COPY_NUM:${sessionId}`)],
      [Markup.button.callback("🔄 Refresh SMS", `REFRESH_SMS:${sessionId}`)],
      [Markup.button.callback("❌ Close Session", `CLOSE_SESSION:${sessionId}`)],
      [Markup.button.callback("⬅️ Back", "MAIN_MENU")]
    ])});
  } catch(e) { return providerError(ctx,e); }
});

bot.action(/^COPY_NUM:(\d+)$/, protectedFeature, async ctx => {
  const s = await db.getSession(Number(ctx.match[1]), ctx.from.id);
  if (!s) return ctx.answerCbQuery("Session not found.", {show_alert:true});
  await ctx.answerCbQuery(s.provider_number, {show_alert:true});
});

async function refreshSession(ctx, sessionId) {
  const s = await db.getSession(sessionId, ctx.from.id);
  if (!s) return ctx.reply("❌ Session not found.");
  if (s.status === "closed" || s.status === "expired") return ctx.reply("❌ This session is closed.");

  try {
    const data = await provider.getRecentUpdates();
    const rows = data?.data?.rows;
    if (!Array.isArray(rows)) throw new ProviderError("Invalid update response.");
    const matching = rows.filter(x => x.number === s.provider_number);
    let added = 0;
    for (const e of matching) if (await db.insertOtpEvent(sessionId,e)) added++;

    if (added === 0) {
      return ctx.reply(`⏳ No new SMS received for <code>${esc(s.provider_number)}</code>.`, {parse_mode:"HTML"});
    }

    const events = await db.pool.query(
      "SELECT sender,message,received_at_ms FROM otp_events WHERE session_id=? ORDER BY id DESC LIMIT 5",
      [sessionId]
    );
    const lines = events[0].map(e => `📩 <b>${esc(e.sender || "SMS")}</b>\n${esc(e.message || "")}`).join("\n\n");
    await ctx.reply(`✅ <b>New SMS received</b>\n\n${lines}`, {parse_mode:"HTML"});
  } catch(e) { return providerError(ctx,e); }
}

bot.action(/^REFRESH_SMS:(\d+)$/, protectedFeature, async ctx => {
  try { await ctx.answerCbQuery("Checking provider..."); } catch {}
  return refreshSession(ctx, Number(ctx.match[1]));
});

bot.action(/^CLOSE_SESSION:(\d+)$/, protectedFeature, async ctx => {
  const s = await db.getSession(Number(ctx.match[1]), ctx.from.id);
  if (!s) return ctx.answerCbQuery("Session not found.", {show_alert:true});
  await db.updateSessionStatus(s.id, "closed");
  await ctx.answerCbQuery("Session closed.");
  await ctx.reply("✅ Local session closed.\n\nThe current provider documentation does not expose a cancellation/release endpoint, so no provider-side cancellation was attempted.");
});

bot.hears("🔎 SEARCH NUMBER", protectedFeature, async ctx => {
  await ctx.reply(
    "🔎 <b>SEARCH NUMBER</b>\n\n" +
    "ZEBRA's supplied documentation does not define an endpoint for searching unallocated numbers. " +
    "I will not invent one.\n\n" +
    "You can search your own active sessions below:",
    {parse_mode:"HTML", ...Markup.inlineKeyboard([
      [Markup.button.callback("📱 My Active Sessions","MY_SESSIONS")],
      [Markup.button.callback("⬅️ Back","MAIN_MENU")]
    ])}
  );
});

bot.action("MY_SESSIONS", protectedFeature, async ctx => {
  const user = await db.getUserByTelegramId(ctx.from.id);
  const rows = await db.getOpenSessions(user.id);
  if (!rows.length) return ctx.reply("📭 No active sessions.", backKeyboard());
  const buttons = rows.slice(0,20).map(s => [Markup.button.callback(`📱 ${s.provider_number} • ${s.status}`, `SESSION:${s.id}`)]);
  await ctx.reply("📱 Your active sessions:", Markup.inlineKeyboard(buttons));
});

bot.action(/^SESSION:(\d+)$/, protectedFeature, async ctx => {
  const s = await db.getSession(Number(ctx.match[1]), ctx.from.id);
  if (!s) return ctx.answerCbQuery("Not found.", {show_alert:true});
  await ctx.answerCbQuery();
  await ctx.reply(
    `📱 <code>${esc(s.provider_number)}</code>\n⏳ ${esc(s.status)}\n🆔 ${s.id}`,
    {parse_mode:"HTML", ...Markup.inlineKeyboard([
      [Markup.button.callback("🔄 Refresh SMS",`REFRESH_SMS:${s.id}`)],
      [Markup.button.callback("❌ Close Session",`CLOSE_SESSION:${s.id}`)],
      [Markup.button.callback("⬅️ Back","MAIN_MENU")]
    ])}
  );
});

bot.hears("👑 TRAFFIC", protectedFeature, async ctx => {
  try {
    const data = await provider.getAvailableRanges();
    const rows = data?.data?.rows;
    if (!Array.isArray(rows)) throw new ProviderError("Invalid traffic response.");
    const lines = rows.slice(0,20).map(r => `📨 ${esc(r.sender)} — ${r.ranges?.length || 0} delivering ranges`);
    await ctx.reply(
      "👑 <b>TRAFFIC</b>\n\n" +
      "Provider documentation does not expose aggregate Total requests / Completed / Pending / Cancelled statistics.\n\n" +
      "Available provider traffic data:\n" + (lines.join("\n") || "No traffic data available."),
      {parse_mode:"HTML", ...backKeyboard()}
    );
  } catch(e) { return providerError(ctx,e); }
});

bot.hears("🔐 2FA ONLINE", protectedFeature, async ctx => {
  await ctx.reply(
    "🔐 <b>2FA ONLINE</b>\n\n" +
    "This section is limited to provider features documented in the supplied ZEBRA API. " +
    "No third-party verification bypass or unauthorized access functionality is implemented.\n\n" +
    "The supplied documentation does not define a separate 2FA API endpoint.",
    {parse_mode:"HTML", ...backKeyboard()}
  );
});

bot.hears("🎁 REFER", protectedFeature, async ctx => {
  const user = await db.getUserByTelegramId(ctx.from.id);
  const stats = await db.getReferralStats(user.id);
  const username = config.botUsername || (await ctx.telegram.getMe()).username;
  const link = `https://t.me/${username}?start=REF_${ctx.from.id}`;
  await ctx.reply(
    `🎁 <b>Referral</b>\n\n🔗 <code>${esc(link)}</code>\n\n` +
    `👥 Referred: <b>${stats.count}</b>\n💰 Referral earnings: <b>${money(stats.earnings)}</b>\n\n` +
    "Referral rewards are only created once per referred account; self-referrals are rejected.",
    {parse_mode:"HTML", ...Markup.inlineKeyboard([[Markup.button.callback("⬅️ Back","MAIN_MENU")]])}
  );
});

bot.hears("💳 WITHDRAWAL", protectedFeature, async ctx => {
  const user = await db.getUserByTelegramId(ctx.from.id);
  const balance = await db.getBalance(ctx.from.id);
  await ctx.reply(
    `💳 <b>Withdrawal</b>\n\n💰 Balance: <b>${money(balance)}</b>\n\nSelect method:`,
    {parse_mode:"HTML", ...Markup.inlineKeyboard([
      [Markup.button.callback("bKash","WD_METHOD:bkash"),Markup.button.callback("Nagad","WD_METHOD:nagad")],
      [Markup.button.callback("USDT","WD_METHOD:usdt")],
      [Markup.button.callback("⬅️ Back","MAIN_MENU")]
    ])}
  );
});

bot.action(/^WD_METHOD:(bkash|nagad|usdt)$/, protectedFeature, async ctx => {
  ctx.session = ctx.session || {};
  ctx.session.withdrawMethod = ctx.match[1];
  await ctx.answerCbQuery();
  await ctx.reply(`💳 ${ctx.match[1].toUpperCase()} selected.\n\nSend the destination/account followed by the amount, for example:\n<code>01XXXXXXXXX 100</code>`, {parse_mode:"HTML"});
});

bot.hears(/^\s*(\S+)\s+(\d+(?:\.\d{1,2})?)\s*$/, protectedFeature, async ctx => {
  const method = ctx.session?.withdrawMethod;
  if (!method) return;
  const destination = ctx.match[1];
  const amount = Number(ctx.match[2]);
  if (!Number.isFinite(amount) || amount <= 0) return ctx.reply("❌ Invalid amount.");
  if (method !== "usdt" && !/^01\d{9}$/.test(destination)) return ctx.reply("❌ Enter a valid bKash/Nagad number.");
  if (method === "usdt" && destination.length < 20) return ctx.reply("❌ Enter a valid USDT wallet address.");
  try {
    const user = await db.getUserByTelegramId(ctx.from.id);
    const id = await db.createWithdrawal(user.id, method, destination, amount);
    ctx.session.withdrawMethod = null;
    await ctx.reply(`⏳ Withdrawal #${id} submitted for admin review.\n💳 ${method.toUpperCase()}\n💰 ${money(amount)}`, mainMenu());
  } catch(e) { await ctx.reply("❌ Withdrawal could not be created. Check your balance and details."); }
});

bot.command("balance", protectedFeature, async ctx => {
  const balance = await db.getBalance(ctx.from.id);
  await ctx.reply(`💰 Balance: <b>${money(balance)}</b>`, {parse_mode:"HTML"});
});

bot.command("admin", async ctx => {
  if (!adminOnly(ctx)) return ctx.reply("❌ Admin access denied.");
  await ctx.reply("👑 <b>Admin Panel</b>", {parse_mode:"HTML", ...Markup.inlineKeyboard([
    [Markup.button.callback("📊 Dashboard","ADMIN_DASH"),Markup.button.callback("👥 Users","ADMIN_USERS")],
    [Markup.button.callback("💳 Withdrawals","ADMIN_WD"),Markup.button.callback("⚙️ Settings","ADMIN_SETTINGS")],
    [Markup.button.callback("📡 Provider","ADMIN_PROVIDER")],
    [Markup.button.callback("⬅️ Main Menu","MAIN_MENU")]
  ])});
});

bot.action(/^ADMIN_/, async ctx => {
  if (!adminOnly(ctx)) return ctx.answerCbQuery("Denied.", {show_alert:true});
  try { await ctx.answerCbQuery(); } catch {}
});

bot.action("ADMIN_DASH", async ctx => {
  const s = await db.stats();
  await ctx.reply(`📊 <b>Dashboard</b>\n\n👥 Users: ${s.users}\n💰 Total user balance: ${money(s.balance)}\n📱 Sessions: ${s.sessions}\n💳 Pending withdrawals: ${s.pendingWithdrawals}`, {parse_mode:"HTML"});
});

bot.action("ADMIN_USERS", async ctx => {
  const rows = await db.listRecentUsers(30);
  const text = rows.map(u => `#${u.id} ${u.telegram_id} ${u.username ? "@"+u.username : ""} | ${money(u.balance)} | ${u.is_banned ? "BANNED":"active"}`).join("\n");
  await ctx.reply("👥 <b>Recent users</b>\n\n"+esc(text || "No users."), {parse_mode:"HTML"});
});

bot.action("ADMIN_WD", async ctx => {
  const rows = await db.listWithdrawals("pending");
  if (!rows.length) return ctx.reply("💳 No pending withdrawals.");
  for (const w of rows) {
    await ctx.reply(
      `💳 <b>Withdrawal #${w.id}</b>\nUser: ${w.telegram_id}\nMethod: ${w.method}\nDestination: <code>${esc(w.destination)}</code>\nAmount: ${money(w.amount)}`,
      {parse_mode:"HTML", ...Markup.inlineKeyboard([
        [Markup.button.callback("✅ Approve",`WD_APPROVE:${w.id}`),Markup.button.callback("❌ Reject",`WD_REJECT:${w.id}`)]
      ])}
    );
  }
});

bot.action(/^WD_(APPROVE|REJECT):(\d+)$/, async ctx => {
  if (!adminOnly(ctx)) return ctx.answerCbQuery("Denied.",{show_alert:true});
  try {
    const approved = ctx.match[1] === "APPROVE";
    const w = await db.reviewWithdrawal(Number(ctx.match[2]), approved, approved ? "Approved by admin" : "Rejected by admin");
    await ctx.answerCbQuery(approved ? "Approved" : "Rejected");
    await ctx.reply(`✅ Withdrawal #${w.id} ${approved ? "approved" : "rejected"}.`);
    const user = await db.getUserByTelegramId(w.telegram_id);
    if (user) await ctx.telegram.sendMessage(w.telegram_id, approved ? `✅ Your withdrawal #${w.id} was approved.` : `❌ Your withdrawal #${w.id} was rejected and refunded.`);
  } catch(e) { await ctx.answerCbQuery(e.message, {show_alert:true}); }
});

bot.action("ADMIN_PROVIDER", async ctx => {
  try {
    const data = await provider.getAvailableRanges();
    const rows = data?.data?.rows || [];
    await ctx.reply("📡 <b>Provider status: OK</b>\n\n" + rows.map(r => `${esc(r.sender)}: ${(r.ranges||[]).length} ranges`).join("\n"), {parse_mode:"HTML"});
  } catch(e) { await ctx.reply(`❌ Provider check failed: ${esc(e.message)}`, {parse_mode:"HTML"}); }
});

bot.action("ADMIN_SETTINGS", async ctx => {
  const s = await db.getSettings();
  await ctx.reply(
    "⚙️ <b>Settings</b>\n\n" +
    `Channel 1: ${esc(s.channel_1_id)}\nChannel 2: ${esc(s.channel_2_id)}\n` +
    `Referral reward: ${money(s.referral_reward)}\nNumber price: ${money(s.number_price)}\n\n` +
    "Admin commands:\n" +
    "/setchannel1 ID URL\n/setchannel2 ID URL\n/setrefreward AMOUNT\n/setprice AMOUNT\n/country RANGE on|off\n/service SENDER on|off\n/addbalance TGID AMOUNT\n/subbalance TGID AMOUNT\n/ban TGID\n/unban TGID\n/transactions TGID\n/sessions\n/broadcast TEXT",
    {parse_mode:"HTML"}
  );
});

bot.command("setchannel1", async ctx => {
  if (!adminOnly(ctx)) return;
  const a = ctx.message.text.split(" ").slice(1);
  if (a.length < 2) return ctx.reply("Usage: /setchannel1 CHANNEL_ID URL");
  await db.setSetting("channel_1_id",a[0]); await db.setSetting("channel_1_url",a[1]);
  await ctx.reply("✅ Channel 1 updated.");
});
bot.command("setchannel2", async ctx => {
  if (!adminOnly(ctx)) return;
  const a = ctx.message.text.split(" ").slice(1);
  if (a.length < 2) return ctx.reply("Usage: /setchannel2 CHANNEL_ID URL");
  await db.setSetting("channel_2_id",a[0]); await db.setSetting("channel_2_url",a[1]);
  await ctx.reply("✅ Channel 2 updated.");
});
bot.command("setrefreward", async ctx => {
  if (!adminOnly(ctx)) return;
  const v=Number(ctx.message.text.split(" ")[1]); if(!Number.isFinite(v)||v<0) return ctx.reply("Invalid amount.");
  await db.setSetting("referral_reward",v.toFixed(2)); await ctx.reply("✅ Referral reward saved.");
});
bot.command("setprice", async ctx => {
  if (!adminOnly(ctx)) return;
  const v=Number(ctx.message.text.split(" ")[1]); if(!Number.isFinite(v)||v<0) return ctx.reply("Invalid amount.");
  await db.setSetting("number_price",v.toFixed(2)); await ctx.reply("✅ Number price saved.");
});
bot.command(["addbalance","subbalance"], async ctx => {
  if (!adminOnly(ctx)) return;
  const a=ctx.message.text.split(" "); const tg=Number(a[1]); const amount=Number(a[2]);
  if(!Number.isSafeInteger(tg)||!Number.isFinite(amount)||amount<=0) return ctx.reply("Usage: /addbalance TGID AMOUNT");
  const u=await db.getUserByTelegramId(tg); if(!u) return ctx.reply("User not found.");
  const delta=ctx.message.text.startsWith("/addbalance")?amount:-amount;
  try { await db.adjustBalance(u.id,delta,"admin_adjustment",`Admin adjustment by ${ctx.from.id}`,"admin",`${ctx.from.id}:${Date.now()}`); await ctx.reply("✅ Balance updated."); }
  catch(e){ await ctx.reply(`❌ ${e.message}`); }
});
bot.command("ban", async ctx => {
  if (!adminOnly(ctx)) return; const tg=Number(ctx.message.text.split(" ")[1]); if(!tg) return ctx.reply("Usage: /ban TGID");
  await db.setBan(tg,true); await ctx.reply("✅ User banned.");
});
bot.command("unban", async ctx => {
  if (!adminOnly(ctx)) return; const tg=Number(ctx.message.text.split(" ")[1]); if(!tg) return ctx.reply("Usage: /unban TGID");
  await db.setBan(tg,false); await ctx.reply("✅ User unbanned.");
});
bot.command("country", async ctx => {
  if (!adminOnly(ctx)) return;
  const a = ctx.message.text.split(/\s+/).slice(1);
  if (a.length < 2 || !["on","off"].includes(a[1].toLowerCase())) return ctx.reply("Usage: /country RANGE on|off");
  await db.pool.query("INSERT INTO countries(range_code,enabled) VALUES(?,?) ON DUPLICATE KEY UPDATE enabled=VALUES(enabled)", [a[0], a[1].toLowerCase()==="on"?1:0]);
  await ctx.reply("✅ Country/range setting updated.");
});

bot.command("service", async ctx => {
  if (!adminOnly(ctx)) return;
  const a = ctx.message.text.split(/\s+/).slice(1);
  if (a.length < 2 || !["on","off"].includes(a[1].toLowerCase())) return ctx.reply("Usage: /service SENDER on|off");
  await db.pool.query("INSERT INTO services(sender,display_name,enabled) VALUES(?,?,?) ON DUPLICATE KEY UPDATE enabled=VALUES(enabled)", [a[0],a[0],a[1].toLowerCase()==="on"?1:0]);
  await ctx.reply("✅ Service setting updated.");
});

bot.command("transactions", async ctx => {
  if (!adminOnly(ctx)) return;
  const tg = Number(ctx.message.text.split(/\s+/)[1]);
  if (!tg) return ctx.reply("Usage: /transactions TGID");
  const u = await db.getUserByTelegramId(tg);
  if (!u) return ctx.reply("User not found.");
  const [rows] = await db.pool.query("SELECT type,amount,balance_after,note,created_at FROM transactions WHERE user_id=? ORDER BY id DESC LIMIT 50",[u.id]);
  const text = rows.map(r => `${r.created_at} | ${r.type} | ${r.amount} | balance ${r.balance_after} | ${r.note||""}`).join("\n");
  await ctx.reply(esc(text || "No transactions."), {parse_mode:"HTML"});
});

bot.command("sessions", async ctx => {
  if (!adminOnly(ctx)) return;
  const [rows] = await db.pool.query("SELECT s.id,u.telegram_id,s.provider_number,s.range_code,s.status,s.created_at FROM sessions s JOIN users u ON u.id=s.user_id ORDER BY s.id DESC LIMIT 100");
  const text = rows.map(r => `#${r.id} ${r.telegram_id} ${r.provider_number} ${r.range_code||""} ${r.status}`).join("\n");
  await ctx.reply(esc(text || "No sessions."), {parse_mode:"HTML"});
});

bot.command("broadcast", async ctx => {
  if (!adminOnly(ctx)) return;
  const message=ctx.message.text.replace(/^\/broadcast\s*/,"").trim(); if(!message) return ctx.reply("Usage: /broadcast TEXT");
  const ids=await db.allTelegramIds(); let ok=0,fail=0;
  for(const id of ids){ try{await ctx.telegram.sendMessage(id,message);ok++;}catch{fail++;} await new Promise(r=>setTimeout(r,40)); }
  await db.pool.query("INSERT INTO broadcasts(admin_telegram_id,message,sent_count,failed_count) VALUES(?,?,?,?)",[ctx.from.id,message,ok,fail]);
  await ctx.reply(`📣 Broadcast complete. Sent: ${ok}, Failed: ${fail}`);
});

bot.hears("👥 SUPPORT", protectedFeature, async ctx => {
  const s=await db.getSettings();
  const support=s.support_username || config.supportUsername;
  await ctx.reply(support ? `👥 <b>Support</b>\n\nContact: ${esc(support)}` : "👥 Support account is not configured yet.", {parse_mode:"HTML", ...backKeyboard()});
});

bot.on("text", protectedFeature, async ctx => {
  if (ctx.message.text.startsWith("/")) return;
  if (ctx.session?.withdrawMethod) return;
  await ctx.reply("ℹ️ Please use the menu buttons.", mainMenu());
});

bot.catch(async (err, ctx) => {
  console.error("Unhandled bot error:", err?.stack || err);
  try { await ctx.reply("⚠️ Something went wrong. Please try again later."); } catch {}
});

let pollBusy = false;
async function providerPollLoop() {
  if (pollBusy) return;
  pollBusy = true;
  try {
    const data = await provider.getRecentUpdates();
    const rows = Array.isArray(data?.data?.rows) ? data.data.rows : [];
    if (rows.length) {
      const [sessions] = await db.pool.query(
        "SELECT s.*,u.telegram_id FROM sessions s JOIN users u ON u.id=s.user_id WHERE s.status IN ('allocated','received') AND (s.provider_expires_ms IS NULL OR s.provider_expires_ms > ?)",
        [Date.now()]
      );
      for (const event of rows) {
        for (const sess of sessions.filter(x => x.provider_number === event.number)) {
          const inserted = await db.insertOtpEvent(sess.id, event);
          if (inserted) {
            try {
              await bot.telegram.sendMessage(
                sess.telegram_id,
                `📩 <b>New SMS received</b>\n\n📱 <code>${esc(event.number)}</code>\n📨 <b>${esc(event.sender || "SMS")}</b>\n${esc(event.message || "")}`,
                {parse_mode:"HTML"}
              );
            } catch (sendErr) { console.error("SMS notification failed:", sendErr.message); }
          }
        }
      }
    }
    await db.pool.query(
      "UPDATE sessions SET status='expired' WHERE status IN ('allocated','received') AND provider_expires_ms IS NOT NULL AND provider_expires_ms <= ?",
      [Date.now()]
    );
  } catch (e) { console.error("Provider poll error:", e.message); }
  finally { pollBusy = false; }
}

async function bootstrap() {
  await db.ping();
  await migrate(config.database);
  await db.seedSettings(config.channels, config.supportUsername);
  if (config.adminId) {
    await db.pool.query("INSERT INTO admins(telegram_id,enabled) VALUES(?,1) ON DUPLICATE KEY UPDATE enabled=1", [config.adminId]);
  }
  await bot.launch();
  console.log("BlackBox OTP bot started.");
  setInterval(providerPollLoop, 5000);
}

bootstrap().catch(err => {
  console.error("Startup failed:", err);
  process.exit(1);
});

process.once("SIGINT", () => bot.stop("SIGINT"));
process.once("SIGTERM", () => bot.stop("SIGTERM"));
