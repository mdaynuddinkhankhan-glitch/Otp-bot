const fs = require("fs");
const path = require("path");
const mysql = require("mysql2/promise");

async function migrate(config) {
  const schemaPath = path.resolve(__dirname, "../schema.sql");
  let sql = fs.readFileSync(schemaPath, "utf8");

  // Railway's MySQL service already creates the configured database.
  // The app user may not have CREATE DATABASE permission, so the runtime
  // migration intentionally removes database-selection statements and runs
  // the table/index/seed statements against DATABASE_URL's database.
  sql = sql
    .replace(/^\s*CREATE\s+DATABASE\s+IF\s+NOT\s+EXISTS[^;]*;\s*/i, "")
    .replace(/^\s*USE\s+[^;]+;\s*/i, "");

  const conn = await mysql.createConnection({
    ...config,
    multipleStatements: true,
    charset: "utf8mb4"
  });

  try {
    await conn.query(sql);
  } finally {
    await conn.end();
  }
}

module.exports = { migrate };
