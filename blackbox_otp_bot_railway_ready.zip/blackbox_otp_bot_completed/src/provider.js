const https = require("https");
const { URL } = require("url");

class ProviderError extends Error {
  constructor(message, code = null, status = null) {
    super(message);
    this.name = "ProviderError";
    this.code = code;
    this.status = status;
  }
}

class ZebraProvider {
  constructor(config) {
    this.baseUrl = config.baseUrl.replace(/\/+$/, "");
    this.apiKey = config.apiKey;
  }

  async request(method, path, body = null) {
    const url = new URL(this.baseUrl + path);
    const payload = body ? JSON.stringify(body) : null;

    return new Promise((resolve, reject) => {
      const req = https.request(url, {
        method,
        timeout: 15000,
        headers: {
          "MAuth": this.apiKey,
          ...(payload ? {
            "Content-Type": "application/json",
            "Content-Length": Buffer.byteLength(payload)
          } : {})
        }
      }, res => {
        let raw = "";
        res.setEncoding("utf8");
        res.on("data", chunk => { raw += chunk; });
        res.on("end", () => {
          let data;
          try {
            data = JSON.parse(raw);
          } catch {
            return reject(new ProviderError("Provider returned invalid JSON.", null, res.statusCode));
          }

          const metaCode = data?.meta?.code;
          if (metaCode !== 0) {
            const known = {
              "-101": "Bad request.",
              "-102": "Provider authentication/account is unauthorized or inactive.",
              "-103": "Provider feature is forbidden or disabled.",
              "-500": "Provider server error."
            };
            return reject(new ProviderError(
              known[String(metaCode)] || data?.meta?.error || data?.message || "Provider request failed.",
              metaCode,
              res.statusCode
            ));
          }
          resolve(data);
        });
      });

      req.on("timeout", () => req.destroy(new Error("Provider request timed out.")));
      req.on("error", err => reject(new ProviderError(err.message)));

      if (payload) req.write(payload);
      req.end();
    });
  }

  async getAvailableRanges(sender = "") {
    const query = sender ? `?sender=${encodeURIComponent(sender)}` : "";
    return this.request("GET", `/publicapi/liveaccess${query}`);
  }

  async requestNumber(range) {
    if (!range || !/^[A-Za-z0-9*Xx+_-]{2,100}$/.test(range)) {
      throw new ProviderError("Invalid range.");
    }
    return this.request("POST", "/publicapi/getnum", { range });
  }

  async getUpdates() {
    return this.request("GET", "/publicapi/getupdate");
  }

  async getRecentUpdates() {
    return this.getUpdates();
  }
}

module.exports = { ZebraProvider, ProviderError };
