# BlackBox OTP Bot — Railway-ready

This project preserves the existing Telegraf structure and adds the requested production-oriented bot features:

- Mandatory two-channel membership gate before protected features
- MySQL persistence and transaction ledger
- Referral links and one-time referral rewards
- Balance locking / duplicate transaction protection
- Withdrawal workflow with bKash, Nagad and USDT
- Admin controls for balances, bans, channels, services/ranges, withdrawals, broadcasts, transactions and sessions
- Documented ZEBRA SMS adapter only
- Provider error mapping, timeouts and safe logging
- Provider polling for newly delivered SMS
- Session expiry tracking
- `.env`/Railway environment variables only
- Runtime database schema initialization for Railway MySQL

## Provider limitation

The supplied ZEBRA documentation shows only:

- `POST /publicapi/getnum` — allocate a number from a requested range
- `GET /publicapi/getupdate` — read recently delivered messages
- `GET /publicapi/liveaccess` — see senders and currently delivering ranges

The project does not invent undocumented country, service, search, cancellation, traffic, or 2FA API endpoints. Features that require undocumented provider endpoints remain limited to the documented data/flows.

## Railway deployment

### 1. Create a Railway project

Create a new Railway project and add this repository/ZIP as the application service. Railway detects the Node.js `package.json` and uses the included `railway.toml` start configuration.

The service starts with:

```bash
npm start
```

### 2. Add MySQL

Add a **MySQL** database service to the same Railway project.

Railway provides `MYSQL_URL` plus the individual MySQL connection variables. Create an application-service variable named `DATABASE_URL` that references the MySQL service:

```text
${{MySQL.MYSQL_URL}}
```

If you rename the database service, use that exact service name in the reference, for example `${{your-db-name.MYSQL_URL}}`.

The app runs the included `schema.sql` automatically at startup against the database in `DATABASE_URL`, so you do not need to manually run the SQL import for a fresh Railway database.

### 3. Add application variables

In the bot service's **Variables** tab, add:

```env
BOT_TOKEN=YOUR_TELEGRAM_BOT_TOKEN
REQUIRED_CHANNEL_1=@your_channel_1
REQUIRED_CHANNEL_2=@your_channel_2
CHANNEL_1_URL=https://t.me/your_channel_1
CHANNEL_2_URL=https://t.me/your_channel_2
ADMIN_ID=YOUR_TELEGRAM_NUMERIC_ID

ZEBRA_BASE_URL=https://api.zebrasms.com/api/v1
ZEBRA_API_KEY=YOUR_NEW_REGENERATED_ZEBRA_KEY

DATABASE_URL=${{MySQL.MYSQL_URL}}

SUPPORT_USERNAME=@your_support
BOT_USERNAME=your_bot_username
```

Do not put real secrets in the repository. Do not use the API key visible in the supplied screenshot; regenerate it first.

### 4. Deploy

After saving variables, deploy the service. Railway will install dependencies and run `npm start`.

Open the deployment logs. A successful startup should contain:

```text
BlackBox OTP bot started.
```

### 5. Restart behavior

`railway.toml` configures Railway's restart policy as `ON_FAILURE` with up to 10 retries. Railway documents this policy as restarting a service after a failed exit. You can change the restart policy from the service settings if your plan supports other options.

### 6. No public web domain is required

This bot uses Telegram long polling, so it does not require a public HTTP domain to receive Telegram updates. The Railway service only needs to stay running.

## Local installation

Node.js 18+ is required/recommended.

```bash
npm install
npm run check
npm start
```

## Telegram setup

1. Create the bot with BotFather.
2. Put the bot token in Railway Variables.
3. Add the bot to both required Telegram channels with enough permissions for `getChatMember` to work.
4. Set the channel IDs/usernames and URLs in Railway Variables.
5. Set `ADMIN_ID` to the administrator's Telegram numeric ID.
6. Deploy/restart the service.
7. Send `/start` to the bot.

## Provider setup

Use the exact documented ZEBRA base URL:

```text
https://api.zebrasms.com/api/v1
```

The adapter sends the key as the `MAuth` header and uses only:

```text
POST /publicapi/getnum
GET  /publicapi/getupdate
GET  /publicapi/liveaccess
```

## Admin commands

```text
/admin
/setchannel1 CHANNEL_ID URL
/setchannel2 CHANNEL_ID URL
/setrefreward AMOUNT
/setprice AMOUNT
/country RANGE on|off
/service SENDER on|off
/addbalance TGID AMOUNT
/subbalance TGID AMOUNT
/ban TGID
/unban TGID
/transactions TGID
/sessions
/broadcast TEXT
```

## Pricing and referrals

The default number price and referral reward are `0.00` because the supplied provider documentation does not specify your customer pricing.

Admin can configure them after startup:

```text
/setprice 5
/setrefreward 1
```

## Security

- Never commit `.env`.
- Never paste the bot token or provider key into source code.
- Regenerate any provider key that has been exposed.
- Do not log secrets.
- Use Railway's Variables/secret management for production values.
- Do not expose `MYSQL_URL` publicly.

## Troubleshooting

### `-101`
Provider rejected the request. Check the documented range/request format.

### `-102`
Provider authentication/account problem. Check the regenerated API key and account status.

### `-103`
The provider feature is forbidden/disabled for the account.

### `-500`
Provider-side server error; retry later.

### Database error
Check that `DATABASE_URL` references the Railway MySQL service and that the MySQL service is deployed in the same Railway project/environment.

### No provider ranges
The bot uses `liveaccess`. If no ranges are returned, the project does not invent numbers/ranges.

### Telegram membership check fails
Confirm the bot can call `getChatMember` for both channels and that the configured channel IDs are correct.
