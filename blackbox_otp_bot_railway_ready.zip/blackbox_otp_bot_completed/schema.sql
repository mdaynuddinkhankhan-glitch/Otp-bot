CREATE DATABASE IF NOT EXISTS blackbox_otp CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE blackbox_otp;

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  telegram_id BIGINT NOT NULL,
  username VARCHAR(255) NULL,
  first_name VARCHAR(255) NULL,
  balance DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  is_banned TINYINT(1) NOT NULL DEFAULT 0,
  referred_by BIGINT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_users_telegram (telegram_id),
  KEY idx_users_referred_by (referred_by),
  KEY idx_users_banned (is_banned)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS transactions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  type ENUM('deposit','purchase','refund','referral_earning','withdrawal','admin_adjustment') NOT NULL,
  amount DECIMAL(18,2) NOT NULL,
  balance_before DECIMAL(18,2) NOT NULL,
  balance_after DECIMAL(18,2) NOT NULL,
  reference_type VARCHAR(64) NULL,
  reference_id VARCHAR(128) NULL,
  note VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_tx_user_created (user_id, created_at),
  UNIQUE KEY uq_tx_reference (reference_type, reference_id),
  CONSTRAINT fk_tx_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS countries (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  range_code VARCHAR(100) NOT NULL,
  country_name VARCHAR(100) NULL,
  iso2 VARCHAR(8) NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_country_range (range_code),
  KEY idx_country_enabled (enabled)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS services (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  sender VARCHAR(255) NOT NULL,
  display_name VARCHAR(255) NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_service_sender (sender),
  KEY idx_service_enabled (enabled)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS sessions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  provider_number VARCHAR(64) NOT NULL,
  range_code VARCHAR(100) NULL,
  country_name VARCHAR(100) NULL,
  iso2 VARCHAR(8) NULL,
  operator_name VARCHAR(100) NULL,
  sender VARCHAR(255) NULL,
  provider_expires_ms BIGINT NULL,
  status ENUM('allocated','received','cancel_requested','expired','closed') NOT NULL DEFAULT 'allocated',
  last_message_at_ms BIGINT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY idx_sessions_user_status (user_id, status),
  KEY idx_sessions_number (provider_number),
  KEY idx_sessions_expiry (provider_expires_ms)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS otp_events (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  session_id BIGINT UNSIGNED NOT NULL,
  provider_number VARCHAR(64) NOT NULL,
  sender VARCHAR(255) NULL,
  message TEXT NULL,
  received_at_ms BIGINT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_otp_event (session_id, received_at_ms, message(120)),
  KEY idx_otp_session (session_id, created_at),
  CONSTRAINT fk_otp_session FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS referrals (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  referrer_user_id BIGINT UNSIGNED NOT NULL,
  referred_user_id BIGINT UNSIGNED NOT NULL,
  reward_amount DECIMAL(18,2) NOT NULL DEFAULT 0.00,
  rewarded TINYINT(1) NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_referral_referred (referred_user_id),
  KEY idx_referral_referrer (referrer_user_id),
  CONSTRAINT fk_ref_referrer FOREIGN KEY (referrer_user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_ref_referred FOREIGN KEY (referred_user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS withdrawals (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  method ENUM('bkash','nagad','usdt') NOT NULL,
  destination VARCHAR(255) NOT NULL,
  amount DECIMAL(18,2) NOT NULL,
  status ENUM('pending','approved','rejected') NOT NULL DEFAULT 'pending',
  admin_note VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  reviewed_at TIMESTAMP NULL,
  PRIMARY KEY (id),
  KEY idx_withdrawals_status_created (status, created_at),
  KEY idx_withdrawals_user (user_id),
  CONSTRAINT fk_withdraw_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS admins (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  telegram_id BIGINT NOT NULL,
  enabled TINYINT(1) NOT NULL DEFAULT 1,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY uq_admin_telegram (telegram_id)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS settings (
  setting_key VARCHAR(100) NOT NULL,
  setting_value TEXT NOT NULL,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (setting_key)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS broadcasts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  admin_telegram_id BIGINT NOT NULL,
  message TEXT NOT NULL,
  sent_count INT NOT NULL DEFAULT 0,
  failed_count INT NOT NULL DEFAULT 0,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id)
) ENGINE=InnoDB;

INSERT INTO settings(setting_key, setting_value) VALUES
('channel_1_id', ''),
('channel_1_url', ''),
('channel_2_id', ''),
('channel_2_url', ''),
('referral_reward', '0.00'),
('support_username', '')
ON DUPLICATE KEY UPDATE setting_key=VALUES(setting_key);

-- After importing, the application seeds the two channel values from .env
-- if the settings are empty.
